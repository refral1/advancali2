do local _ = {
	plug = {
    "TD"
  },
  Helper = "HelperEagleboT",
  Token = "412174902:AAGA4EzGr3Ct7hobFoGzGBnQzC-XIXUzshQ",
  bot_owner = {
    484131026,
    499929818
  },
  cmd = "^[/!#]",
  sudo_users = {
    484131026
  }
}
return _
end